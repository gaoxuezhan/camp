cd azkaban-exec-server-0.1.0-SNAPSHOT
sh bin/start-exec.sh
cd ..
cd azkaban-web-server-0.1.0-SNAPSHOT
sh bin/start-web.sh
